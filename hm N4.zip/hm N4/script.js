const arr = [
    "e",
    "l",
   "e",
   "p",
   "h",
   "a",
   "n",
   "t" 
]

arr.sort()
console.log(arr)